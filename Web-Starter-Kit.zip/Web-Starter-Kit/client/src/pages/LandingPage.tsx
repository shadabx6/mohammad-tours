import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSchema, type InsertContact } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone, Mail, MapPin, MessageSquare, ShieldCheck, Globe, Users, Plane, Hotel, Car, CheckCircle, Smartphone, Star, XCircle, Info, Calendar, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export default function LandingPage() {
  const { toast } = useToast();
  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
      city: "",
      travelMonth: "",
      selectedPackage: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertContact) => {
      await apiRequest("POST", "/api/contact", data);
      const ownerNumber = "917368990121";
      const message = `Assalamualaikum Mohammad Tours & Travels,

I am interested in Umrah Package.

Name: ${data.name}
Mobile: ${data.phone}
City: ${data.city}
Travel Month: ${data.travelMonth || "Not specified"}
Selected Package: ${data.selectedPackage || "Not specified"}

Please contact me with full details.`;

      const url = `https://wa.me/${ownerNumber}?text=${encodeURIComponent(message)}`;
      window.open(url, "_blank");
    },
    onSuccess: () => {
      toast({
        title: "Booking Request Sent",
        description: "Opening WhatsApp to confirm your booking...",
      });
      form.reset();
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Something went wrong. Please try again.",
      });
    },
  });

  const scrollToContact = (packageName?: string) => {
    if (packageName) {
      form.setValue("selectedPackage", packageName);
    }
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const packages = [
    {
      id: "super-saver",
      name: "SUPER SAVER UMRAH",
      price: "84,000",
      description: "Lowest Price – Budget Friendly",
      bestFor: ["First time Umrah", "Kam budget wale pilgrims", "Group me jane wale log"],
      benefits: [
        "Saudi Umrah Visa",
        "Visa Insurance",
        "Economy Air Ticket (Air India / Saudi)",
        "3★ Hotel (Makkah & Madinah)",
        "Room Sharing (4–5 Bed)",
        "Jeddah Airport → Hotel Bus Transfer",
        "Hotel Free Wi-Fi",
        "1 Guide per 50 pilgrims",
        "Umrah basic guidance & coordination",
        "5 Liter Zamzam Free"
      ],
      notIncluded: [
        "Personal car",
        "Luxury hotel",
        "Unlimited laundry",
        "Premium Umrah kit"
      ]
    },
    {
      id: "budget",
      name: "BUDGET UMRAH",
      price: "89,000",
      description: "Best Value for Money",
      bestFor: ["Family ke saath jane wale", "Thoda comfort chahne wale", "Budget + facilities dono"],
      benefits: [
        "Saudi Umrah Visa + Insurance",
        "Economy Air Ticket",
        "Better 3★ Hotel (Better Location)",
        "Room Sharing (4 Bed)",
        "Meals Included (as per hotel timing)",
        "Airport → Hotel Bus Transfer",
        "Hotel Free Wi-Fi",
        "1 Guide per 50 pilgrims",
        "Basic Umrah Kit",
        "5 Liter Zamzam Free"
      ]
    },
    {
      id: "semi-deluxe",
      name: "SEMI DELUXE UMRAH",
      price: "99,000",
      description: "Comfort + Professional Service",
      bestFor: ["Family / elders", "Thoda comfort & better management chahne wale"],
      benefits: [
        "Saudi Umrah Visa + Insurance",
        "Economy / Preferred Air Ticket",
        "3★ / 4★ Hotel",
        "Room Sharing (4 / 3 / 2 Bed options)",
        "Meals Included",
        "Airport → Hotel Transfer (Bus / shared vehicle)",
        "Hotel Free Wi-Fi",
        "1–2 Experienced Guides per 50 pilgrims",
        "Umrah Kit (Handbag + Carry Bag + Dua Book)",
        "Laundry (limited)",
        "5 Liter Zamzam Free"
      ]
    },
    {
      id: "luxury",
      name: "LUXURY UMRAH",
      price: "1,15,000",
      prefix: "From",
      description: "Premium & Tension-Free Umrah",
      bestFor: ["Family, elders, business class people", "Jo full comfort & privacy chahte hain"],
      benefits: [
        "Saudi Umrah Visa + Full Visa Insurance",
        "Preferred Airline (Air India / Saudi)",
        "4★ Hotel (Near Haram)",
        "Room Options (4 Bed / 2 Bed / Private)",
        "Personal Car / Dedicated Vehicle",
        "Airport → Hotel → Ziyarat → Airport Personal Transfer",
        "Meals Unlimited (hotel timing)",
        "Free Hotel Wi-Fi",
        "Laundry Free",
        "2 Guides per 50 pilgrims",
        "Premium Umrah Kit",
        "Special assistance for elders",
        "5 Liter Zamzam Free"
      ]
    }
  ];

  return (
    <div className="min-h-screen font-sans bg-[#fcfaf5] overflow-x-hidden">
      {/* Premium Top Bar */}
      <div className="bg-[#001a13] text-[#d4af37] py-2 text-[10px] uppercase tracking-[0.3em] font-black border-b border-[#d4af37]/20">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <span>Serving Pilgrims Since 2013</span>
          <div className="flex gap-4">
            <span>Bihar • Jharkhand • UP • All India</span>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <header className="bg-[#002d1f]/95 backdrop-blur-md border-b border-[#d4af37]/40 py-4 sticky top-0 z-50 shadow-2xl">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3 group cursor-pointer"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          >
            <div className="relative">
              <span className="text-5xl text-[#d4af37] drop-shadow-lg">🕌</span>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#d4af37] rounded-full animate-ping opacity-75" />
            </div>
            <div className="flex flex-col">
              <span className="text-3xl font-serif font-black text-[#d4af37] tracking-tighter leading-none italic group-hover:text-white transition-colors">Mohammad</span>
              <span className="text-[10px] text-[#d4af37] tracking-[0.4em] uppercase font-bold leading-none mt-1 opacity-80">Tours & Travels</span>
            </div>
          </motion.div>
          
          <nav className="hidden lg:flex gap-10 text-white font-bold uppercase text-[11px] tracking-[0.2em]">
            {["Home", "About Us", "Packages", "Services", "Contact"].map((item) => (
              <a 
                key={item} 
                href={item === "Contact" ? "#contact" : `#${item.toLowerCase().replace(" ", "")}`} 
                className="hover:text-[#d4af37] transition-all relative group py-2"
              >
                {item}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#d4af37] transition-all group-hover:w-full" />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <Button 
              onClick={() => scrollToContact()}
              className="bg-gradient-to-r from-[#d4af37] to-[#f4ead5] text-[#002d1f] px-6 py-2.5 rounded-full flex items-center gap-3 font-black shadow-[0_0_20px_rgba(212,175,55,0.4)] text-sm hover:scale-105 transition-transform border border-[#d4af37]"
            >
              <Calendar className="w-4 h-4" />
              Book Online
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative min-h-[700px] flex items-center justify-start text-left px-4 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-fixed bg-center z-0"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=1920&q=80')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent z-10" />
        <div className="absolute inset-0 islamic-pattern z-10" />
        
        <div className="relative z-20 max-w-5xl container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-3 bg-[#d4af37]/20 backdrop-blur-md border border-[#d4af37]/40 px-5 py-2 rounded-full">
              <Star className="w-4 h-4 text-[#d4af37] fill-[#d4af37]" />
              <span className="text-[#d4af37] text-xs font-black uppercase tracking-[0.3em]">Licensed & Approved Agent</span>
            </div>
            
            <h1 className="text-5xl md:text-8xl font-serif font-black text-white leading-[0.95] drop-shadow-2xl">
              Trusted & Affordable <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4af37] via-[#f4ead5] to-[#d4af37]">Umrah Packages</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-white/90 font-medium max-w-2xl leading-relaxed">
              Experience a seamless spiritual journey with premium <span className="text-[#d4af37] font-bold">3★ & 4★ accommodations</span>, comprehensive visa services, and dedicated religious guidance.
            </p>

            <div className="flex flex-wrap gap-6 pt-6">
              <Button 
                onClick={() => scrollToContact()}
                size="lg" 
                className="bg-[#d4af37] text-[#002d1f] hover:bg-white hover:text-[#002d1f] font-black px-12 py-8 rounded-none shadow-2xl transition-all border-b-4 border-[#8e7223] text-lg uppercase tracking-widest"
              >
                Online Booking
              </Button>
              <Button size="lg" className="bg-transparent text-[#d4af37] hover:bg-[#d4af37]/10 border-2 border-[#d4af37] font-black px-12 py-8 rounded-none shadow-2xl transition-all text-lg uppercase tracking-widest" asChild>
                <a href="https://wa.me/917368990121" target="_blank" rel="noopener noreferrer">WhatsApp Chat</a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Packages Section */}
      <section id="packages" className="py-24 textured-bg relative overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="text-center mb-24 space-y-4">
            <h2 className="text-5xl md:text-7xl font-serif font-black text-[#002d1f] tracking-tighter">Choose Your Package</h2>
            <p className="text-[#d4af37] font-black uppercase tracking-[0.4em] text-xs underline underline-offset-8 decoration-2 decoration-[#d4af37]/30">Spiritual Comfort Within Your Reach</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            {packages.map((pkg, idx) => (
              <motion.div
                key={idx}
                whileHover={{ y: -10 }}
                className="flex flex-col h-full"
              >
                <Card className="border-0 rounded-none overflow-hidden package-card-shadow bg-white flex flex-col flex-1 group relative">
                  {/* Decorative Border */}
                  <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-[#d4af37] via-[#fcf8f0] to-[#d4af37]" />
                  
                  {/* Header */}
                  <div className="pt-12 pb-8 text-center px-6 bg-[#fcfaf5]/80">
                    <h3 className="text-2xl font-serif font-black text-[#002d1f] mb-3 tracking-tight group-hover:text-[#d4af37] transition-colors">{pkg.name}</h3>
                    <div className="inline-flex items-center gap-2 bg-[#002d1f] text-[#d4af37] px-6 py-4 border-2 border-[#d4af37] shadow-[5px_5px_0px_rgba(212,175,55,0.2)]">
                      {pkg.prefix && <span className="text-[10px] block opacity-80 uppercase tracking-widest font-black mb-0.5 mr-1">{pkg.prefix}</span>}
                      <span className="text-4xl font-serif font-black italic tracking-tighter">₹{pkg.price}</span>
                    </div>
                    <p className="text-[11px] uppercase font-black text-[#002d1f]/60 tracking-widest italic mt-6 border-y border-[#d4af37]/10 py-2">{pkg.description}</p>
                  </div>

                  {/* Body */}
                  <CardContent className="p-8 flex-1 space-y-10 bg-white relative">
                    <div className="absolute inset-0 islamic-pattern pointer-events-none opacity-[0.03]" />
                    
                    {/* Best For Section */}
                    <div className="relative">
                      <p className="text-[10px] font-black text-[#002d1f] uppercase tracking-[0.3em] mb-4 flex items-center gap-2">
                        <Sparkles className="w-3 h-3 text-[#d4af37]" />
                        Kis ke liye best?
                      </p>
                      <ul className="grid grid-cols-1 gap-2">
                        {pkg.bestFor.map((item, i) => (
                          <li key={i} className="text-[12px] text-[#002d1f]/80 font-bold bg-[#fcf8f0] px-3 py-1.5 border-l-4 border-[#d4af37] leading-snug">
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Benefits Section */}
                    <div className="relative">
                      <p className="text-[10px] font-black text-[#002d1f] uppercase tracking-[0.3em] mb-4 border-b border-[#d4af37]/20 pb-2">✅ Benefits Include:</p>
                      <ul className="space-y-3">
                        {pkg.benefits.map((item, i) => (
                          <li key={i} className="flex items-start gap-3">
                            <div className="bg-[#25d366]/10 p-1 rounded-full shrink-0 mt-0.5">
                              <CheckCircle className="w-3.5 h-3.5 text-[#25d366]" />
                            </div>
                            <span className="text-[12px] font-bold text-[#002d1f] leading-tight">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Exclusions Section */}
                    {pkg.notIncluded && (
                      <div className="relative opacity-70">
                        <p className="text-[10px] font-black text-red-600 uppercase tracking-[0.3em] mb-3 border-b border-red-500/20 pb-2">❌ Not Included:</p>
                        <ul className="space-y-2">
                          {pkg.notIncluded.map((item, i) => (
                            <li key={i} className="flex items-start gap-3">
                              <XCircle className="w-3.5 h-3.5 text-red-500/50 shrink-0 mt-0.5" />
                              <span className="text-[11px] font-bold text-red-600/70 leading-tight italic">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Action Button */}
                    <Button 
                      onClick={() => scrollToContact(pkg.name)}
                      className="w-full bg-[#002d1f] text-[#d4af37] hover:bg-[#d4af37] hover:text-[#002d1f] font-black uppercase tracking-[0.3em] text-[11px] py-9 rounded-none border-2 border-[#d4af37] transition-all duration-700 shadow-[0_10px_20px_-5px_rgba(0,0,0,0.3)] relative overflow-hidden group/btn"
                    >
                      <span className="relative z-10">Confirm Booking</span>
                      <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover/btn:translate-x-[100%] transition-transform duration-1000" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Common Points Banner */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="mt-24 bg-[#002d1f] border-l-8 border-[#d4af37] p-10 md:p-16 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-96 h-96 islamic-pattern opacity-10 -rotate-12 translate-x-1/2 -translate-y-1/2" />
            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-16 items-center">
              <div>
                <div className="inline-flex items-center gap-3 bg-[#d4af37]/20 border border-[#d4af37]/30 px-6 py-2 rounded-full mb-6">
                  <Info className="w-5 h-5 text-[#d4af37]" />
                  <span className="text-[#d4af37] text-[11px] font-black uppercase tracking-[0.4em]">Important Terms</span>
                </div>
                <h3 className="text-4xl font-serif font-black text-white mb-3 italic">Common Points</h3>
                <p className="text-[#d4af37] text-[11px] font-black uppercase tracking-[0.5em] opacity-60">Sab packages ke liye ek saman</p>
              </div>
              <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-10 text-[13px] text-white/90 font-bold uppercase tracking-[0.1em] leading-relaxed">
                <p className="flex items-start gap-5 bg-white/5 p-4 border border-white/10"><span className="text-[#d4af37] text-2xl">✦</span> Personal shopping / souvenirs → Customer apne paiso se</p>
                <p className="flex items-start gap-5 bg-white/5 p-4 border border-white/10"><span className="text-[#d4af37] text-2xl">✦</span> Jo likha hoga package me → wahi services milengi</p>
                <p className="flex items-start gap-5 bg-white/5 p-4 border border-white/10"><span className="text-[#d4af37] text-2xl">✦</span> Managed as per Airline, hotel & transport availability</p>
                <div className="bg-gradient-to-r from-[#d4af37] to-[#f4ead5] text-[#002d1f] p-6 text-center border-b-8 border-black/30 flex items-center justify-center">
                  <p className="text-sm font-black tracking-[0.4em]">ALL INDIA SERVICE AVAILABLE</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Signature About Section */}
      <section id="aboutus" className="bg-white">
        <div className="dark-green-section py-20 text-center relative border-b-8 border-[#d4af37]">
          <div className="container mx-auto px-4 relative z-20">
             <div className="flex items-center justify-center gap-6 mb-4">
               <div className="h-0.5 w-16 bg-[#d4af37]" />
               <h2 className="text-5xl md:text-7xl font-serif font-black text-[#d4af37] tracking-tighter italic">About Our Agency</h2>
               <div className="h-0.5 w-16 bg-[#d4af37]" />
            </div>
            <p className="text-[#d4af37] uppercase tracking-[0.5em] text-xs font-black">Spiritual Excellence Since 2013</p>
          </div>
          <div className="absolute top-0 left-0 w-full h-full islamic-pattern opacity-10" />
        </div>
        
        <div className="container mx-auto px-4 py-32 textured-bg">
          <div className="flex flex-col lg:flex-row gap-20 items-center max-w-7xl mx-auto">
            <div className="w-full lg:w-1/2 relative">
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                className="relative z-10 border-[15px] border-white shadow-[0_50px_100px_-20px_rgba(0,0,0,0.4)] gold-border-glow"
              >
                <img 
                  src="https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&w=1000&q=80" 
                  alt="Umrah Pilgrims" 
                  className="w-full grayscale hover:grayscale-0 transition-all duration-1000"
                />
              </motion.div>
              <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-[#d4af37]/10 -z-10 rounded-full blur-3xl" />
              <div className="absolute -top-10 -left-10 w-64 h-64 bg-[#002d1f]/10 -z-10 rounded-full blur-3xl" />
            </div>
            
            <div className="w-full lg:w-1/2 space-y-12">
              <div className="space-y-10">
                {[
                  { title: "Over 10 Years of Legacy", desc: "Building trust through thousand of successful journeys." },
                  { title: "Qualified Religious Guides", desc: "Expert scholars to guide you through every ritual." },
                  { title: "Unmatched Integrity", desc: "Complete transparency in pricing and documentation." }
                ].map((item, idx) => (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, x: 50 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.2 }}
                    className="flex gap-8 group"
                  >
                    <div className="bg-[#002d1f] text-[#d4af37] p-5 shadow-2xl border-r-4 border-[#d4af37] h-fit group-hover:bg-[#d4af37] group-hover:text-[#002d1f] transition-all duration-500">
                      <CheckCircle className="w-8 h-8" />
                    </div>
                    <div>
                      <h4 className="text-2xl font-serif font-black text-[#002d1f] mb-2">{item.title}</h4>
                      <p className="text-sm font-bold text-[#002d1f]/60 uppercase tracking-widest leading-loose">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Form with Elite Design */}
      <section id="contact" className="py-32 textured-bg relative border-y border-[#d4af37]/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-24 space-y-4">
            <h2 className="text-5xl md:text-7xl font-serif font-black text-[#002d1f] tracking-tighter">Reserve Your Spot</h2>
            <p className="text-[#d4af37] font-black uppercase tracking-[0.5em] text-xs underline underline-offset-8 decoration-2 decoration-[#d4af37]/30">Official Booking Form</p>
          </div>
          
          <div className="flex flex-col lg:flex-row gap-24 max-w-7xl mx-auto">
            <div className="w-full lg:w-2/5 space-y-12">
              <div className="group bg-[#002d1f] p-10 shadow-2xl border-b-8 border-[#d4af37] transition-all hover:-translate-y-2">
                <div className="flex items-center gap-6 mb-6">
                  <div className="bg-[#d4af37] p-4 rounded-full shadow-lg shadow-[#d4af37]/20">
                    <Phone className="w-8 h-8 text-[#002d1f]" />
                  </div>
                  <h3 className="text-2xl font-serif font-black text-white">Direct Line</h3>
                </div>
                <p className="text-4xl font-serif font-black text-[#d4af37] tracking-tighter italic">+91 7368990121</p>
              </div>

            </div>

            <div className="w-full lg:w-3/5">
              <Card className="border-0 rounded-none p-1 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.3)] bg-gradient-to-br from-[#d4af37] to-[#8e7223]">
                <div className="bg-[#fcfaf5] p-10 md:p-16 h-full">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-10">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input placeholder="Full Name *" {...field} className="border-0 border-b-2 border-[#d4af37]/30 bg-transparent rounded-none h-14 text-lg focus:border-[#002d1f] transition-all px-0 font-bold" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input type="tel" placeholder="Mobile Number *" {...field} className="border-0 border-b-2 border-[#d4af37]/30 bg-transparent rounded-none h-14 text-lg focus:border-[#002d1f] transition-all px-0 font-bold" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <FormField
                          control={form.control}
                          name="city"
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input placeholder="Your City *" {...field} value={field.value || ""} className="border-0 border-b-2 border-[#d4af37]/30 bg-transparent rounded-none h-14 text-lg focus:border-[#002d1f] transition-all px-0 font-bold" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="selectedPackage"
                          render={({ field }) => (
                            <FormItem>
                              <Select onValueChange={field.onChange} defaultValue={field.value || undefined} value={field.value || undefined}>
                                <FormControl>
                                  <SelectTrigger className="border-0 border-b-2 border-[#d4af37]/30 bg-transparent rounded-none h-14 text-lg focus:ring-0 px-0 font-black text-[#002d1f]">
                                    <SelectValue placeholder="Desired Package" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent className="rounded-none border-2 border-[#d4af37]">
                                  {packages.map(p => (
                                    <SelectItem key={p.id} value={p.name}>{p.name} (₹{p.price})</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Textarea placeholder="Special Requirements..." rows={4} {...field} className="border-2 border-[#d4af37]/30 bg-transparent rounded-none text-lg focus:border-[#002d1f] transition-all font-medium" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button 
                        type="submit" 
                        className="w-full bg-[#002d1f] text-[#d4af37] text-2xl font-serif font-black py-10 hover:bg-[#d4af37] hover:text-[#002d1f] shadow-2xl uppercase tracking-[0.3em] transition-all duration-700 border-b-8 border-[#000] whitespace-normal h-auto leading-tight px-4"
                        disabled={mutation.isPending}
                      >
                        {mutation.isPending ? "Submitting..." : "Send Booking Request"}
                      </Button>
                    </form>
                  </Form>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Majestic Footer */}
      <footer className="bg-[#001a13] text-[#d4af37] pt-32 pb-16 border-t-8 border-[#d4af37]">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-24 text-center md:text-left mb-32">
          <div className="space-y-10">
             <div className="flex items-center gap-4 justify-center md:justify-start">
               <span className="text-6xl">🕌</span>
               <div className="flex flex-col">
                 <span className="text-4xl font-serif font-black leading-none italic">Mohammad</span>
                 <span className="text-xs tracking-[0.5em] uppercase font-bold mt-1 opacity-70">Tours & Travels</span>
               </div>
            </div>
            <p className="text-[#d4af37]/60 text-lg leading-loose font-serif italic border-l-2 border-[#d4af37]/30 pl-8">
              "Experience the sacred journey with trust and comfort. We are committed to providing the best Umrah services since 2013."
            </p>
          </div>

          <div className="space-y-10">
            <h4 className="text-3xl font-serif font-black uppercase tracking-widest border-b-4 border-[#d4af37] pb-4 inline-block italic">Contact Info</h4>
            <div className="space-y-8 text-xl font-bold">
              <a href="tel:+917368990121" className="flex items-center gap-6 justify-center md:justify-start hover:text-white transition-colors group">
                <div className="bg-[#d4af37] p-3 rounded-full group-hover:bg-white transition-colors">
                  <Phone className="w-6 h-6 text-[#001a13]" />
                </div>
                <span>+91 7368999221</span>
              </a>
            </div>
          </div>

          <div className="space-y-10">
             <h4 className="text-3xl font-serif font-black uppercase tracking-widest border-b-4 border-[#d4af37] pb-4 inline-block italic">Explore</h4>
             <div className="flex flex-col gap-6 font-black uppercase text-xs tracking-[0.4em]">
               {["Home", "About Us", "Packages", "Services"].map(item => (
                 <a key={item} href={`#${item.toLowerCase().replace(" ", "")}`} className="hover:text-white transition-all flex items-center gap-3 justify-center md:justify-start">
                   <span className="text-2xl text-[#d4af37]">✦</span> {item}
                 </a>
               ))}
             </div>
          </div>
        </div>
        
        <div className="border-t border-[#d4af37]/10 pt-16 text-center container mx-auto px-4 flex flex-col items-center gap-6">
          <div className="text-[#d4af37] text-4xl mb-4">✧ ✦ ✧</div>
          <p className="text-[10px] opacity-40 uppercase tracking-[0.6em] font-black">© 2026 Mohammad Tours & Travels</p>
        </div>
      </footer>

      {/* Luxurious Floating WhatsApp */}
      <a
        href="https://wa.me/917368999221"
        className="fixed bottom-10 right-10 bg-gradient-to-br from-[#25d366] to-[#128c7e] text-white p-6 rounded-full shadow-[0_20px_50px_rgba(37,211,102,0.4)] z-50 hover:scale-110 transition-transform border-4 border-white/20 animate-float"
        target="_blank"
        rel="noopener noreferrer"
      >
        <Smartphone className="w-10 h-10" />
      </a>
    </div>
  );
}
